# Auto Verification Token Sender - Backend & Deployment Guide

## Overview
This system automatically monitors newly created verification tokens in Firebase Firestore (`auto-verification-bf6cd`) and dispatches secure, sanitized notifications to a designated Telegram chat via the official Telegram Bot API within 2 seconds.

---

## 1. Firebase Integration Setup

1. **Install Firebase CLI**:
   ```bash
   npm install -g firebase-tools
   firebase login
   ```

2. **Select Project**:
   ```bash
   firebase use auto-verification-bf6cd
   ```

3. **Deploy Firestore Security Rules**:
   ```bash
   firebase deploy --only firestore:rules
   ```

---

## 2. Telegram Bot API Integration

1. Open Telegram and search for `@BotFather`.
2. Send `/newbot` and follow instructions to name your bot (e.g. `AutoTokenSenderBot`).
3. Copy the HTTP API token (e.g., `7123456789:AAH...`).
4. Obtain your Target Telegram Chat ID:
   - For private chat: message `@userinfobot` or forward a message to `@getmyid_bot` to find your user ID.
   - For a Telegram channel or group: add your bot to the group as administrator, then invite `@RawDataBot` to view the group's negative Chat ID (e.g. `-100192837482`).

---

## 3. Secure Backend Secrets Configuration

Configure secrets using Google Cloud / Firebase Secret Manager:
```bash
# Set Telegram Bot Token securely
firebase functions:secrets:set TELEGRAM_BOT_TOKEN
# Paste your bot token when prompted

# Set Target Telegram Chat ID
firebase functions:secrets:set TELEGRAM_CHAT_ID
# Paste your chat ID when prompted
```

Deploy Cloud Functions:
```bash
cd backend/functions
npm install
firebase deploy --only functions
```

---

## 4. Android APK Build Instructions

1. **Prerequisites**: Android SDK 36 (Java 17/21).
2. **Build Debug APK**:
   ```bash
   gradle :app:assembleDebug
   ```
   Output: `app/build/outputs/apk/debug/app-debug.apk`

3. **Build Release APK**:
   ```bash
   gradle :app:assembleRelease
   ```
   Output: `app/build/outputs/apk/release/app-release.apk`

---

## 5. Security & Privacy Protocol

- **Zero-Secret Notification Policy**: Notifications to Telegram include ONLY:
  - Application Name
  - Token reference ID (e.g., `TKN-849201`)
  - Creation timestamp
  - Verification status (`AUTHORIZED`)
- **Strictly Excluded**: Passwords, OTP codes, authorization headers, private encryption keys, or authentication secrets are NEVER transmitted to external chat channels.
- **Deduplication**: Guaranteed at-most-once delivery using Firestore transactions and duplicate check guards.
