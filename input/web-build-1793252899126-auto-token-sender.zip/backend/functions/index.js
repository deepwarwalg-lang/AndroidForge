/**
 * Auto Verification Token Sender - Cloud Functions
 *
 * Automatically dispatches authorized verification token notifications
 * to configured Telegram chat via official Telegram Bot API.
 *
 * Target delivery time: < 2 seconds under normal conditions.
 * Deduplication: Atomic check-and-set to guarantee at-most-once delivery.
 * Security: Strict field filtering to avoid exposing sensitive secrets or OTPs.
 */

const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");
const fetch = require("node-fetch");

admin.initializeApp();
const db = admin.firestore();

// Define Cloud Secret Manager secrets for sensitive credentials
const telegramBotToken = defineSecret("TELEGRAM_BOT_TOKEN");
const telegramChatId = defineSecret("TELEGRAM_CHAT_ID");

/**
 * Validates verification token record
 * @param {Object} data - Document data
 * @returns {{isValid: boolean, reason?: string}}
 */
function validateTokenRecord(data) {
  if (!data) {
    return { isValid: false, reason: "Empty document payload" };
  }

  // Token ID or reference ID is mandatory
  const tokenRef = data.tokenRef || data.id;
  if (!tokenRef || typeof tokenRef !== "string" || tokenRef.trim().length === 0) {
    return { isValid: false, reason: "Missing or invalid token reference ID" };
  }

  // Check authorization status
  const status = (data.status || "").toUpperCase();
  if (status !== "AUTHORIZED" && status !== "APPROVED" && data.isAuthorized !== true) {
    return { isValid: false, reason: `Token status '${status}' is not authorized for notification` };
  }

  // Timestamp check
  if (!data.createdAt) {
    return { isValid: false, reason: "Missing creation timestamp" };
  }

  return { isValid: true };
}

/**
 * Builds safe Telegram notification text
 * CRITICAL SECURITY RULE: Never include passwords, OTPs, or secrets.
 * @param {Object} token - Sanitized token data
 * @returns {string} - Formatted Telegram HTML message
 */
function formatNotificationMessage(token) {
  const appName = escapeHtml(token.appName || "Auto Token Sender");
  const tokenRef = escapeHtml(token.tokenRef || token.id || "N/A");
  const status = escapeHtml((token.status || "AUTHORIZED").toUpperCase());

  let formattedDate = "Just now";
  if (token.createdAt) {
    try {
      const date = typeof token.createdAt.toDate === "function"
        ? token.createdAt.toDate()
        : new Date(token.createdAt);
      formattedDate = date.toISOString().replace("T", " ").substring(0, 19) + " UTC";
    } catch (e) {
      formattedDate = new Date().toISOString();
    }
  }

  return (
    `<b>🔐 Authorized Verification Token</b>\n\n` +
    `📱 <b>Application:</b> ${appName}\n` +
    `🏷️ <b>Token Reference:</b> <code>${tokenRef}</code>\n` +
    `⏱️ <b>Created At:</b> ${formattedDate}\n` +
    `✅ <b>Status:</b> <b>${status}</b>\n\n` +
    `<i>⚡ Automatically dispatched via Firebase Cloud Functions (<2s)</i>`
  );
}

function escapeHtml(text) {
  if (!text) return "";
  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

/**
 * Sends message to Telegram with safe timeout and retry logic
 */
async function sendTelegramMessage(botToken, chatId, htmlText, maxRetries = 2) {
  const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
  const body = {
    chat_id: chatId,
    text: htmlText,
    parse_mode: "HTML",
    disable_web_page_preview: true,
  };

  let attempt = 0;
  while (attempt <= maxRetries) {
    attempt++;
    const startTime = Date.now();
    try {
      const controller = new (global.AbortController || require("abort-controller"))();
      const timeoutId = setTimeout(() => controller.abort(), 2000); // 2-second target timeout

      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);
      const data = await response.json();
      const latencyMs = Date.now() - startTime;

      if (response.ok && data.ok) {
        return {
          success: true,
          messageId: data.result ? data.result.message_id : null,
          latencyMs,
        };
      }

      // Handle Telegram rate limits or transient errors
      if (response.status === 429 && attempt <= maxRetries) {
        const retryAfter = (data.parameters && data.parameters.retry_after) || 1;
        await new Promise((r) => setTimeout(r, retryAfter * 1000));
        continue;
      }

      throw new Error(`Telegram API Error ${response.status}: ${data.description || "Unknown error"}`);
    } catch (err) {
      if (attempt > maxRetries) {
        throw err;
      }
      // Brief backoff before next attempt
      await new Promise((r) => setTimeout(r, 400 * attempt));
    }
  }
}

/**
 * Cloud Function Trigger: onDocumentCreated in collection 'verification_tokens'
 */
exports.onVerificationTokenCreated = onDocumentCreated(
  {
    document: "verification_tokens/{tokenId}",
    secrets: [telegramBotToken, telegramChatId],
    region: "us-central1",
    timeoutSeconds: 15,
    memory: "256MiB",
    maxInstances: 10,
  },
  async (event) => {
    const snap = event.data;
    if (!snap) {
      console.log("No data associated with the event");
      return;
    }

    const tokenId = event.params.tokenId;
    const docRef = snap.ref;
    const tokenData = snap.data();

    console.log(`[Token ${tokenId}] Processing new token creation event...`);

    // 1. Check duplicate flag in initial snapshot
    if (tokenData.processed === true || tokenData.telegramSent === true) {
      console.log(`[Token ${tokenId}] Token already processed. Skipping to avoid duplicate send.`);
      return;
    }

    // 2. Validate token record schema and authorization status
    const validation = validateTokenRecord(tokenData);
    if (!validation.isValid) {
      console.warn(`[Token ${tokenId}] Validation failed: ${validation.reason}. Skipping.`);
      await docRef.update({
        processed: true,
        telegramSent: false,
        processingNote: `Validation skipped: ${validation.reason}`,
        processedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
      return;
    }

    // 3. Obtain Telegram Bot credentials securely
    const botToken = telegramBotToken.value() || process.env.TELEGRAM_BOT_TOKEN;
    const chatId = telegramChatId.value() || process.env.TELEGRAM_CHAT_ID;

    if (!botToken || !chatId) {
      const errMsg = "Missing TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID in environment secrets.";
      console.error(errMsg);
      await docRef.update({
        error: errMsg,
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
      return;
    }

    // 4. Atomic Deduplication Lock via Firestore Transaction
    let shouldProceed = false;
    await db.runTransaction(async (transaction) => {
      const freshSnap = await transaction.get(docRef);
      if (!freshSnap.exists) return;

      const freshData = freshSnap.data();
      if (freshData.processed === true || freshData.isDispatching === true) {
        console.log(`[Token ${tokenId}] Atomic lock check: already processed or currently dispatching.`);
        return;
      }

      // Mark temporary dispatch lock
      transaction.update(docRef, {
        isDispatching: true,
        dispatchStartedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
      shouldProceed = true;
    });

    if (!shouldProceed) {
      return;
    }

    // 5. Construct sanitized message and send to Telegram
    const formattedMessage = formatNotificationMessage({
      id: tokenId,
      appName: tokenData.appName || "Auto Token Sender",
      tokenRef: tokenData.tokenRef || tokenId,
      status: tokenData.status || "AUTHORIZED",
      createdAt: tokenData.createdAt,
    });

    try {
      const sendResult = await sendTelegramMessage(botToken, chatId, formattedMessage);
      console.log(`[Token ${tokenId}] Telegram sent in ${sendResult.latencyMs}ms. Message ID: ${sendResult.messageId}`);

      // 6. Record delivery status and update token record
      await docRef.update({
        processed: true,
        telegramSent: true,
        isDispatching: false,
        sentAt: admin.firestore.FieldValue.serverTimestamp(),
        telegramMessageId: sendResult.messageId,
        deliveryLatencyMs: sendResult.latencyMs,
        telegramChatId: chatId,
      });

      // Also record to notifications_audit collection for centralized auditing
      await db.collection("notification_audit").add({
        tokenId,
        tokenRef: tokenData.tokenRef || tokenId,
        appName: tokenData.appName || "Auto Token Sender",
        status: "DELIVERED",
        telegramMessageId: sendResult.messageId,
        deliveryLatencyMs: sendResult.latencyMs,
        timestamp: admin.firestore.FieldValue.serverTimestamp(),
      });
    } catch (err) {
      console.error(`[Token ${tokenId}] Failed to send Telegram message:`, err.message);
      await docRef.update({
        processed: false,
        telegramSent: false,
        isDispatching: false,
        lastError: err.message,
        retryScheduled: true,
        lastAttemptAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    }
  }
);
