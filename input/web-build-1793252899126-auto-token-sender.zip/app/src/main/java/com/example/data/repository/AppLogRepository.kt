package com.example.data.repository

import android.util.Log
import com.example.data.local.LogDao
import com.example.data.model.LogEntity
import com.example.data.model.LogLevel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

open class AppLogRepository(
    private val logDao: LogDao
) {
    private val coroutineScope = CoroutineScope(Dispatchers.IO)

    fun getLogs(): Flow<List<LogEntity>> = logDao.getRecentLogs()

    fun getErrorCount(): Flow<Int> = logDao.getErrorCount()

    fun log(level: LogLevel, tag: String, message: String, details: String? = null) {
        when (level) {
            LogLevel.INFO -> Log.i(tag, "$message: $details")
            LogLevel.WARN -> Log.w(tag, "$message: $details")
            LogLevel.ERROR -> Log.e(tag, "$message: $details")
            LogLevel.SUCCESS -> Log.d(tag, "$message: $details")
        }

        coroutineScope.launch {
            try {
                logDao.insertLog(
                    LogEntity(
                        timestamp = System.currentTimeMillis(),
                        level = level.name,
                        tag = tag,
                        message = message,
                        details = details
                    )
                )
            } catch (e: Exception) {
                Log.e("AppLogRepository", "Failed to write log to DB", e)
            }
        }
    }

    suspend fun clearLogs() {
        logDao.clearLogs()
    }
}
