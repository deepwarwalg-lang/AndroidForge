package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tech Cyan & Deep Slate Palette
val CyanPrimary = Color(0xFF00D4FF)
val CyanPrimaryVariant = Color(0xFF0284C7)
val CyanOnPrimary = Color(0xFF031E2B)
val CyanPrimaryContainer = Color(0xFF083344)
val CyanOnPrimaryContainer = Color(0xFFBAE6FD)

val SecondaryTeal = Color(0xFF2DD4BF)
val SecondaryOn = Color(0xFF00382E)
val SecondaryContainer = Color(0xFF0D3D38)
val SecondaryOnContainer = Color(0xFF99F6E4)

val TertiaryIndigo = Color(0xFF818CF8)
val TertiaryOn = Color(0xFF1E1B4B)
val TertiaryContainer = Color(0xFF312E81)
val TertiaryOnContainer = Color(0xFFC7D2FE)

val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1F2937)
val DarkSurfaceBorder = Color(0xFF374151)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightSurfaceBorder = Color(0xFFE2E8F0)

val StatusSuccess = Color(0xFF10B981)
val StatusSuccessContainer = Color(0xFF064E3B)
val StatusWarning = Color(0xFFF59E0B)
val StatusWarningContainer = Color(0xFF78350F)
val StatusError = Color(0xFFEF4444)
val StatusErrorContainer = Color(0xFF7F1D1D)
val StatusInfo = Color(0xFF38BDF8)
