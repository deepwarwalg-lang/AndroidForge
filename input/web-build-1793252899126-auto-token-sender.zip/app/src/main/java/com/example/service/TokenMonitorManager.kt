package com.example.service

import com.example.data.local.HistoryDao
import com.example.data.model.HistoryEntity
import com.example.data.model.LogLevel
import com.example.data.model.VerificationToken
import com.example.data.repository.AppLogRepository
import com.example.data.repository.ConfigRepository
import com.example.data.repository.FirestoreTokenRepository
import com.example.data.repository.TelegramRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

data class MonitorStats(
    val isRunning: Boolean = false,
    val totalDetected: Int = 0,
    val totalDispatched: Int = 0,
    val totalFailed: Int = 0,
    val averageLatencyMs: Long = 0L,
    val lastDispatchedAt: Long? = null,
    val statusText: String = "Idle"
)

class TokenMonitorManager(
    private val firestoreRepo: FirestoreTokenRepository,
    private val telegramRepo: TelegramRepository,
    private val configRepo: ConfigRepository,
    private val historyDao: HistoryDao,
    private val logger: AppLogRepository,
    private val externalScope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    private var monitorJob: Job? = null

    // In-memory set of processed token IDs to guarantee zero in-session duplicates
    private val processedTokenIds = ConcurrentHashMap.newKeySet<String>()

    private val _stats = MutableStateFlow(MonitorStats())
    val stats: StateFlow<MonitorStats> = _stats.asStateFlow()

    private val latencySum = java.util.concurrent.atomic.AtomicLong(0L)
    private val dispatchedCount = java.util.concurrent.atomic.AtomicInteger(0)

    fun startMonitoring() {
        if (monitorJob != null && monitorJob?.isActive == true) return

        configRepo.setMonitoringActive(true)
        _stats.value = _stats.value.copy(
            isRunning = true,
            statusText = "Listening for new tokens in real-time"
        )
        logger.log(LogLevel.INFO, "Monitor", "Token monitoring service started")

        monitorJob = firestoreRepo.observeTokens()
            .onEach { tokens ->
                handleIncomingTokens(tokens)
            }
            .launchIn(externalScope)
    }

    fun stopMonitoring() {
        monitorJob?.cancel()
        monitorJob = null
        configRepo.setMonitoringActive(false)
        _stats.value = _stats.value.copy(
            isRunning = false,
            statusText = "Monitoring paused"
        )
        logger.log(LogLevel.INFO, "Monitor", "Token monitoring paused by user")
    }

    private suspend fun handleIncomingTokens(tokens: List<VerificationToken>) {
        val config = configRepo.configFlow.value
        if (!config.isMonitoringActive) return

        for (token in tokens) {
            val tokenId = token.id.ifBlank { token.tokenRef }
            if (tokenId.isBlank()) continue

            // 1. Duplicate check: Skip if already processed in-memory or flagged in document
            if (processedTokenIds.contains(tokenId) || token.processed || token.telegramSent) {
                // Ensure cached locally
                processedTokenIds.add(tokenId)
                continue
            }

            // 2. Validate token schema and authorization
            val (isValid, reason) = token.isValidForNotification()
            if (!isValid) {
                logger.log(
                    LogLevel.WARN,
                    "Monitor",
                    "Token $tokenId skipped: $reason"
                )
                continue
            }

            // 3. Check App ID filter if configured
            if (config.filterAppId.isNotBlank() && !token.appId.contains(config.filterAppId, ignoreCase = true)) {
                continue
            }

            // Mark in progress in local set to prevent concurrent double-dispatch
            processedTokenIds.add(tokenId)
            _stats.value = _stats.value.copy(totalDetected = _stats.value.totalDetected + 1)

            logger.log(
                LogLevel.INFO,
                "Monitor",
                "New authorized token detected: ${token.tokenRef.ifBlank { tokenId }}",
                "Status: ${token.status} | Created: ${token.createdAt}"
            )

            // If auto-forward is enabled on Android
            if (config.autoForwardDirectly) {
                processAndDispatchToken(token, config.telegramBotToken, config.telegramChatId)
            }
        }
    }

    private suspend fun processAndDispatchToken(
        token: VerificationToken,
        botToken: String,
        chatId: String
    ) {
        val tokenId = token.id.ifBlank { token.tokenRef }
        val sanitizedHtml = telegramRepo.buildSanitizedNotificationHtml(token)

        if (botToken.isBlank() || chatId.isBlank()) {
            val err = "Telegram credentials not configured in settings."
            logger.log(LogLevel.ERROR, "Monitor", err)
            recordHistoryFailure(token, sanitizedHtml, err)
            _stats.value = _stats.value.copy(totalFailed = _stats.value.totalFailed + 1)
            return
        }

        val result = telegramRepo.sendVerificationTokenNotification(
            token = botToken,
            chatId = chatId,
            record = token
        )

        result.fold(
            onSuccess = { (messageId, latencyMs) ->
                val newCount = dispatchedCount.incrementAndGet()
                val totalLatency = latencySum.addAndGet(latencyMs)
                val avg = totalLatency / newCount

                _stats.value = _stats.value.copy(
                    totalDispatched = newCount,
                    averageLatencyMs = avg,
                    lastDispatchedAt = System.currentTimeMillis()
                )

                // Update Firestore document
                firestoreRepo.markTokenProcessed(
                    tokenId = tokenId,
                    telegramMessageId = messageId,
                    latencyMs = latencyMs
                )

                // Save to local Room history
                historyDao.insertOrUpdate(
                    HistoryEntity(
                        tokenId = tokenId,
                        tokenRef = token.tokenRef.ifBlank { tokenId },
                        appName = token.appName,
                        status = token.status,
                        timestamp = System.currentTimeMillis(),
                        telegramMessageId = messageId,
                        deliveryLatencyMs = latencyMs,
                        isSuccess = true,
                        sanitizedPayload = sanitizedHtml
                    )
                )
            },
            onFailure = { error ->
                _stats.value = _stats.value.copy(totalFailed = _stats.value.totalFailed + 1)
                firestoreRepo.markTokenProcessed(
                    tokenId = tokenId,
                    telegramMessageId = null,
                    latencyMs = null,
                    error = error.localizedMessage
                )
                recordHistoryFailure(token, sanitizedHtml, error.localizedMessage ?: "Dispatch error")
            }
        )
    }

    private suspend fun recordHistoryFailure(
        token: VerificationToken,
        payload: String,
        error: String
    ) {
        val tokenId = token.id.ifBlank { token.tokenRef }
        historyDao.insertOrUpdate(
            HistoryEntity(
                tokenId = tokenId,
                tokenRef = token.tokenRef.ifBlank { tokenId },
                appName = token.appName,
                status = token.status,
                timestamp = System.currentTimeMillis(),
                telegramMessageId = null,
                deliveryLatencyMs = null,
                isSuccess = false,
                sanitizedPayload = payload,
                errorDetails = error
            )
        )
    }

    fun clearStats() {
        dispatchedCount.set(0)
        latencySum.set(0L)
        _stats.value = MonitorStats(isRunning = monitorJob?.isActive == true)
    }
}
