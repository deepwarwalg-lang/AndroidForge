package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class LogLevel {
    INFO,
    WARN,
    ERROR,
    SUCCESS
}

@Entity(tableName = "system_logs")
data class LogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val level: String = LogLevel.INFO.name,
    val tag: String,
    val message: String,
    val details: String? = null
)
