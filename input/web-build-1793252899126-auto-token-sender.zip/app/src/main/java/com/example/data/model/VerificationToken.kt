package com.example.data.model

import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

/**
 * Verification Token record stored in Firestore collection 'verification_tokens'
 */
data class VerificationToken(
    @DocumentId
    val id: String = "",
    val appId: String = "com.rtajj",
    val appName: String = "Auto Token Sender",
    val tokenRef: String = "",
    val status: String = "AUTHORIZED", // AUTHORIZED, PENDING, VERIFIED, REVOKED
    val isAuthorized: Boolean = true,
    @ServerTimestamp
    val createdAt: Date? = null,
    val processed: Boolean = false,
    val telegramSent: Boolean = false,
    val sentAt: Date? = null,
    val telegramMessageId: Long? = null,
    val deliveryLatencyMs: Long? = null,
    val lastError: String? = null,
    val processingNote: String? = null
) {
    /**
     * Checks if this record is valid and ready for notification
     */
    fun isValidForNotification(): Pair<Boolean, String> {
        if (tokenRef.isBlank() && id.isBlank()) {
            return false to "Missing token reference ID"
        }
        val s = status.uppercase()
        if (s != "AUTHORIZED" && s != "APPROVED" && !isAuthorized) {
            return false to "Status '$status' is not authorized"
        }
        return true to "Valid"
    }
}
