package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.TelegramApiService
import com.example.data.local.AppDatabase
import com.example.data.model.AppConfig
import com.example.data.model.HistoryEntity
import com.example.data.model.LogEntity
import com.example.data.model.LogLevel
import com.example.data.model.VerificationToken
import com.example.data.repository.AppLogRepository
import com.example.data.repository.ConfigRepository
import com.example.data.repository.FirestoreTokenRepository
import com.example.data.repository.TelegramRepository
import com.example.service.MonitorStats
import com.example.service.TokenMonitorManager
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class FirebaseConnectionState(
    val isConnected: Boolean = false,
    val latencyMs: Long = -1L,
    val projectId: String = "auto-verification-bf6cd",
    val checking: Boolean = false
)

data class TelegramConnectionState(
    val isConnected: Boolean = false,
    val botUsername: String? = null,
    val botFirstName: String? = null,
    val latencyMs: Long = -1L,
    val checking: Boolean = false,
    val lastError: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    val logRepository = AppLogRepository(db.logDao())
    val configRepository = ConfigRepository(application)

    private val telegramApi = TelegramApiService.create()
    val telegramRepository = TelegramRepository(telegramApi, logRepository)

    // Ensure Firebase is initialized
    init {
        try {
            FirebaseApp.initializeApp(application)
        } catch (_: Exception) {}
    }

    private val firestore = FirebaseFirestore.getInstance()
    val firestoreRepository = FirestoreTokenRepository(firestore, logRepository)

    val monitorManager = TokenMonitorManager(
        firestoreRepo = firestoreRepository,
        telegramRepo = telegramRepository,
        configRepo = configRepository,
        historyDao = db.historyDao(),
        logger = logRepository,
        externalScope = viewModelScope
    )

    // State flows
    val config: StateFlow<AppConfig> = configRepository.configFlow
    val monitorStats: StateFlow<MonitorStats> = monitorManager.stats

    val historyList: StateFlow<List<HistoryEntity>> = db.historyDao().getAllHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val logList: StateFlow<List<LogEntity>> = db.logDao().getRecentLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val firestoreTokens: StateFlow<List<VerificationToken>> = firestoreRepository.observeTokens()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _firebaseState = MutableStateFlow(FirebaseConnectionState())
    val firebaseState: StateFlow<FirebaseConnectionState> = _firebaseState.asStateFlow()

    private val _telegramState = MutableStateFlow(TelegramConnectionState())
    val telegramState: StateFlow<TelegramConnectionState> = _telegramState.asStateFlow()

    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    init {
        // Auto-check connections
        checkFirebaseConnection()
        testTelegramBot(config.value.telegramBotToken)

        // Automatically start monitoring if configured
        if (config.value.isMonitoringActive) {
            monitorManager.startMonitoring()
        }
    }

    fun dismissUserMessage() {
        _userMessage.value = null
    }

    fun checkFirebaseConnection() {
        viewModelScope.launch(Dispatchers.IO) {
            _firebaseState.value = _firebaseState.value.copy(checking = true)
            val (connected, latency) = firestoreRepository.checkConnection()
            val projectId = firestoreRepository.getProjectId()
            _firebaseState.value = FirebaseConnectionState(
                isConnected = connected,
                latencyMs = latency,
                projectId = projectId,
                checking = false
            )
            logRepository.log(
                if (connected) LogLevel.SUCCESS else LogLevel.WARN,
                "Firebase",
                if (connected) "Firebase connected (${latency}ms)" else "Firebase ping failed",
                "Project: $projectId"
            )
        }
    }

    fun testTelegramBot(token: String? = null) {
        val targetToken = token ?: config.value.telegramBotToken
        if (targetToken.isBlank()) {
            _telegramState.value = TelegramConnectionState(
                isConnected = false,
                lastError = "Bot token not configured"
            )
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _telegramState.value = _telegramState.value.copy(checking = true, lastError = null)
            val startTime = System.currentTimeMillis()
            val result = telegramRepository.testBotToken(targetToken)
            val latency = System.currentTimeMillis() - startTime

            result.fold(
                onSuccess = { user ->
                    _telegramState.value = TelegramConnectionState(
                        isConnected = true,
                        botUsername = user.username,
                        botFirstName = user.firstName,
                        latencyMs = latency,
                        checking = false,
                        lastError = null
                    )
                },
                onFailure = { error ->
                    _telegramState.value = TelegramConnectionState(
                        isConnected = false,
                        latencyMs = latency,
                        checking = false,
                        lastError = error.localizedMessage
                    )
                }
            )
        }
    }

    fun toggleMonitoring() {
        if (monitorStats.value.isRunning) {
            monitorManager.stopMonitoring()
            _userMessage.value = "Monitoring paused"
        } else {
            monitorManager.startMonitoring()
            _userMessage.value = "Monitoring started"
        }
    }

    fun saveConfig(
        botToken: String,
        chatId: String,
        autoForward: Boolean,
        filterAppId: String,
        soundAlerts: Boolean
    ) {
        configRepository.updateConfig(
            botToken = botToken,
            chatId = chatId,
            autoForward = autoForward,
            filterAppId = filterAppId,
            soundAlerts = soundAlerts
        )
        testTelegramBot(botToken)
        _userMessage.value = "Configuration saved successfully"
    }

    fun generateTestVerificationToken(
        appName: String = "Auto Token Sender",
        status: String = "AUTHORIZED",
        customRef: String? = null
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = firestoreRepository.createToken(appName, status, customRef)
            result.fold(
                onSuccess = { docId ->
                    _userMessage.value = "Simulated token created in Firestore! Watch it dispatch."
                },
                onFailure = { err ->
                    _userMessage.value = "Failed to create token: ${err.localizedMessage}"
                }
            )
        }
    }

    fun sendTestMessage() {
        val conf = config.value
        if (conf.telegramBotToken.isBlank() || conf.telegramChatId.isBlank()) {
            _userMessage.value = "Please configure Telegram Bot Token and Chat ID first."
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            val dummyToken = VerificationToken(
                id = "TEST-PING-${System.currentTimeMillis() % 10000}",
                appId = "com.rtajj",
                appName = "Auto Token Sender (Test Ping)",
                tokenRef = "TKN-PING-${(1000..9999).random()}",
                status = "AUTHORIZED",
                isAuthorized = true
            )

            val result = telegramRepository.sendVerificationTokenNotification(
                token = conf.telegramBotToken,
                chatId = conf.telegramChatId,
                record = dummyToken
            )

            result.fold(
                onSuccess = { (msgId, latency) ->
                    _userMessage.value = "Test notification sent! Message ID: $msgId (${latency}ms)"
                },
                onFailure = { err ->
                    _userMessage.value = "Test notification failed: ${err.localizedMessage}"
                }
            )
        }
    }

    fun clearHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            db.historyDao().clearHistory()
            monitorManager.clearStats()
            _userMessage.value = "Notification history cleared"
        }
    }

    fun clearLogs() {
        viewModelScope.launch(Dispatchers.IO) {
            logRepository.clearLogs()
            _userMessage.value = "Error logs cleared"
        }
    }
}
