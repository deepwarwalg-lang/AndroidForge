package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notification_history")
data class HistoryEntity(
    @PrimaryKey
    val tokenId: String,
    val tokenRef: String,
    val appName: String,
    val status: String,
    val timestamp: Long,
    val telegramMessageId: Long?,
    val deliveryLatencyMs: Long?,
    val isSuccess: Boolean,
    val sanitizedPayload: String,
    val errorDetails: String? = null
)
